V-Eats individual SQL worksheets

Read the Word guide first. Each member has a separate section and SQL file.
Primary demo: enter individual SQL statements in SQL*Plus and explain each result.
These paused scripts are optional rehearsal helpers.

Extract this ZIP into your existing V-Eats project folder so sql/members exists.
Open Windows Command Prompt in that project folder and run:

docker start oracle-free
docker exec oracle-free healthcheck.sh
docker exec oracle-free mkdir -p /tmp/veats-members
docker cp sql/members/. oracle-free:/tmp/veats-members
docker exec -it oracle-free sqlplus /nolog

At SQL>, enter:
CONNECT VEATS_APP@//127.0.0.1:1521/FREEPDB1

Enter your own ORACLE_PASSWORD from .env.local at the hidden password prompt.
Do not show passwords on the projector. No browser admin key is needed.
Then run ONLY your own worksheet:

Shriya: @/tmp/veats-members/shriya.sql
Trisha: @/tmp/veats-members/trisha.sql
Tanisi: @/tmp/veats-members/tanisi.sql
Asmi: @/tmp/veats-members/asmi.sql
Soha: @/tmp/veats-members/soha.sql

The script pauses after steps. Explain each output before pressing Enter.
Finish cleanup before rerunning. See your guide section for interrupted-run recovery.
The seeded Oracle schema must already exist; fresh setup is in the guide.
The application uses node-oracledb Thin, not Java JDBC.
